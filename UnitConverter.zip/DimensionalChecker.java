package Hackathon;
import java.util.HashMap;
import java.util.Map;

public class DimensionalChecker {

    private Map<String, String> dimensions = new HashMap<>();

    public DimensionalChecker() {

        // Length
        dimensions.put("m", "L");
        dimensions.put("cm", "L");
        dimensions.put("km", "L");

        // Mass
        dimensions.put("kg", "M");
        dimensions.put("g", "M");
        dimensions.put("mg", "M");

        // Time
        dimensions.put("sec", "T");
        dimensions.put("min", "T");
        dimensions.put("hr", "T");

        // Temperature
        dimensions.put("C", "TEMP");
        dimensions.put("F", "TEMP");
        dimensions.put("K", "TEMP");

        // Area
        dimensions.put("sqm", "A");
        dimensions.put("sqcm", "A");
        dimensions.put("sqkm", "A");

        // Volume
        dimensions.put("l", "V");
        dimensions.put("ml", "V");
        dimensions.put("m3", "V");
    }

    public boolean checkSameDimension(String unit1, String unit2) {
        return dimensions.containsKey(unit1)
                && dimensions.containsKey(unit2)
                && dimensions.get(unit1).equals(dimensions.get(unit2));
    }
}