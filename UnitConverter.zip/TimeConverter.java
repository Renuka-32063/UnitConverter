package Hackathon;
import java.util.HashMap;
import java.util.Map;

public class TimeConverter implements Converter {

    private Map<String, Double> baseFactor = new HashMap<>();

    public TimeConverter() {
        baseFactor.put("sec", 1.0);
        baseFactor.put("min", 60.0);
        baseFactor.put("hr", 3600.0);
        baseFactor.put("day", 86400.0);
    }

    @Override
    public double convert(double value, String fromUnit, String toUnit)
            throws IncompatibleUnitException {

        if (!baseFactor.containsKey(fromUnit) || !baseFactor.containsKey(toUnit)) {
            throw new IncompatibleUnitException("Invalid time units.");
        }

        return value * (baseFactor.get(fromUnit) / baseFactor.get(toUnit));
    }
}
