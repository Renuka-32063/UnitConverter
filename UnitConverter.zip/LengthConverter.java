package Hackathon;

import java.util.HashMap;
import java.util.Map;

public class LengthConverter implements Converter {

    private Map<String, Double> baseFactor = new HashMap<>();

    public LengthConverter() {
        baseFactor.put("m", 1.0);
        baseFactor.put("cm", 0.01);
        baseFactor.put("km", 1000.0);
    }

    @Override
    public double convert(double value, String fromUnit, String toUnit)
            throws IncompatibleUnitException {

        if (!baseFactor.containsKey(fromUnit) || !baseFactor.containsKey(toUnit)) {
            throw new IncompatibleUnitException("Invalid length units.");
        }

        return value * (baseFactor.get(fromUnit) / baseFactor.get(toUnit));
    }
}