package Hackathon;

public abstract class Quantity {
    protected double value;
    protected String unit;

    public Quantity(double value, String unit) {
        this.value = value;
        this.unit = unit;
    }

    public double getValue() {
        return value;
    }

    public String getUnit() {
        return unit;
    }
}
