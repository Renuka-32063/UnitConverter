package Hackathon;

public interface Converter {
    double convert(double value, String fromUnit, String toUnit)
            throws IncompatibleUnitException;
}