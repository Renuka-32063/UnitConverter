package Hackathon;

import java.util.HashMap;
import java.util.Map;

public class MassConverter implements Converter {

    private Map<String, Double> baseFactor = new HashMap<>();

    public MassConverter() {
        baseFactor.put("kg", 1.0);
        baseFactor.put("g", 0.001);
    }

    @Override
    public double convert(double value, String fromUnit, String toUnit)
            throws IncompatibleUnitException {

        if (!baseFactor.containsKey(fromUnit) || !baseFactor.containsKey(toUnit)) {
            throw new IncompatibleUnitException("Invalid mass units.");
        }

        return value * (baseFactor.get(fromUnit) / baseFactor.get(toUnit));
    }
}