package Hackathon;

import java.util.HashMap;
import java.util.Map;

public class VolumeConverter implements Converter {

    private Map<String, Double> baseFactor = new HashMap<>();

    public VolumeConverter() {
        baseFactor.put("l", 1.0);
        baseFactor.put("ml", 0.001);
        baseFactor.put("m3", 1000.0);
    }

    @Override
    public double convert(double value, String fromUnit, String toUnit)
            throws IncompatibleUnitException {

        if (!baseFactor.containsKey(fromUnit) || !baseFactor.containsKey(toUnit)) {
            throw new IncompatibleUnitException("Invalid volume units.");
        }

        return value * (baseFactor.get(fromUnit) / baseFactor.get(toUnit));
    }
}