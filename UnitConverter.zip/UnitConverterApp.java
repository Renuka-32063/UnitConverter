package Hackathon;

import java.io.*;
import java.util.Scanner;

public class UnitConverterApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        LengthConverter lengthConv = new LengthConverter();
        MassConverter massConv = new MassConverter();
        TimeConverter timeConv = new TimeConverter();
        TemperatureConverter tempConv = new TemperatureConverter();
        AreaConverter areaConv = new AreaConverter();
        VolumeConverter volumeConv = new VolumeConverter();

        DimensionalChecker checker = new DimensionalChecker();

        try {
            // INPUT
            System.out.print("Enter value: ");
            double value = sc.nextDouble();

            System.out.print("Enter from unit: ");
            String from = sc.next();

            System.out.print("Enter to unit: ");
            String to = sc.next();

            // SAVE INPUT
            writeToFile("input_log.txt", value + " " + from + " " + to);

            // DIMENSION CHECK
            if (!checker.checkSameDimension(from, to)) {
                System.out.println("ERROR: Dimension mismatch");
                writeToFile("conversion_history.txt",
                        value + " " + from + " -> ERROR");
                return;
            }

            // CONVERSION
            double result;

            if (from.equals("m") || from.equals("cm") || from.equals("km")) {
                result = lengthConv.convert(value, from, to);

            } else if (from.equals("kg") || from.equals("g") || from.equals("mg")) {
                result = massConv.convert(value, from, to);

            } else if (from.equals("sec") || from.equals("min") || from.equals("hr")) {
                result = timeConv.convert(value, from, to);

            } else if (from.equals("C") || from.equals("F") || from.equals("K")) {
                result = tempConv.convert(value, from, to);

            } else if (from.equals("sqm") || from.equals("sqcm") || from.equals("sqkm")) {
                result = areaConv.convert(value, from, to);

            } else if (from.equals("l") || from.equals("ml") || from.equals("m3")) {
                result = volumeConv.convert(value, from, to);

            } else {
                System.out.println("Unsupported unit.");
                return;
            }

            // OUTPUT
            System.out.println("Converted Value: " + result + " " + to);

            // SAVE OUTPUT + HISTORY
            writeToFile("output_log.txt",
                    value + " " + from + " -> " + result + " " + to);

            writeToFile("conversion_history.txt",
                    value + " " + from + " -> " + result + " " + to);

            // SHOW HISTORY
            System.out.print("Show history? (yes/no): ");
            if (sc.next().equalsIgnoreCase("yes")) {
                readHistory();
            }

        } catch (Exception e) {
            System.out.println("Invalid input.");
        }

        sc.close();
    }

    // WRITE TO FILE
    static void writeToFile(String fileName, String data) {
        try (BufferedWriter bw =
                     new BufferedWriter(new FileWriter(fileName, true))) {
            bw.write(data);
            bw.newLine();
        } catch (IOException e) {
            System.out.println("File error.");
        }
    }

    // READ HISTORY
    static void readHistory() {
        System.out.println("\n--- History ---");
        try (BufferedReader br =
                     new BufferedReader(new FileReader("conversion_history.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("No history found.");
        }
    }
}