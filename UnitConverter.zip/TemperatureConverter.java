package Hackathon;
public class TemperatureConverter implements Converter {

    @Override
    public double convert(double value, String fromUnit, String toUnit)
            throws IncompatibleUnitException {

        if (fromUnit.equals("C") && toUnit.equals("F")) {
            return (value * 9 / 5) + 32;
        } 
        else if (fromUnit.equals("F") && toUnit.equals("C")) {
            return (value - 32) * 5 / 9;
        } 
        else if (fromUnit.equals("C") && toUnit.equals("K")) {
            return value + 273.15;
        } 
        else if (fromUnit.equals("K") && toUnit.equals("C")) {
            return value - 273.15;
        } 
        else {
            throw new IncompatibleUnitException("Invalid temperature units.");
        }
    }
}