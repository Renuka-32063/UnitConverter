package Hackathon;

public class IncompatibleUnitException extends Exception {
    public IncompatibleUnitException(String message) {
        super(message);
    }
}
