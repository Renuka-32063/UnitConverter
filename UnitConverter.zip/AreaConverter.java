package Hackathon;
import java.util.HashMap;
import java.util.Map;

public class AreaConverter implements Converter {

    private Map<String, Double> baseFactor = new HashMap<>();

    public AreaConverter() {
        baseFactor.put("sqm", 1.0);
        baseFactor.put("sqcm", 0.0001);
        baseFactor.put("sqkm", 1_000_000.0);
    }

    
    public double convert(double value, String fromUnit, String toUnit)
            throws IncompatibleUnitException {

        if (!baseFactor.containsKey(fromUnit) || !baseFactor.containsKey(toUnit)) {
            throw new IncompatibleUnitException("Invalid area units.");
        }

        return value * (baseFactor.get(fromUnit) / baseFactor.get(toUnit));
    }
}